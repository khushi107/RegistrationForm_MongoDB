const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();
const PORT = 5000;

// Middleware
app.use(cors());
app.use(bodyParser.json());

// MongoDB Connection
mongoose.connect('mongodb://localhost:27017/registrationDB');


mongoose.connection.on('connected', () => {
    console.log('Connected to MongoDB');
});

mongoose.connection.on('error', (err) => {
    console.log('MongoDB connection error:', err);
});

// User Schema
const userSchema = new mongoose.Schema({
    name: String,
    email: { type: String, required: true, unique: true },
    password: String,
});

const User = mongoose.model('User', userSchema);

// POST route for registration
app.post('/register', (req, res) => {
    const { name, email, password } = req.body;

    const newUser = new User({ name, email, password });

    newUser.save()
        .then(() => {
            res.status(200).send('User registered successfully');
        })
        .catch((err) => {
            res.status(500).send('Error registering user: ' + err.message);
        });
});

// Start the server
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
